import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http'
import { Book } from './book';

const httpOptions = {
  headers: new HttpHeaders({ 'Content-type': 'application/json' })
};


@Injectable({
  providedIn: 'root'
})
export class BookService {

  private userUrl = 'http://localhost:4444/';

  constructor(private http: HttpClient) { }

  public getBooks() {
    console.log('hedhdghdgd')
    return this.http.get<Book[]>(this.userUrl + 'getAllBookDetails', httpOptions);
  }
  public deleteBook(book) {
    return this.http.get(this.userUrl + 'removeBookDetails/{'+ book.isbn+'}', book);
  }
  public createBook(book) {
    console.log(book)
    return this.http.post(this.userUrl+'acceptBookDetails',JSON.stringify(book), httpOptions);
  }
}
