export class Book {
    bookCategory:string;
	bookName:string;
	authorName:string;
	isbn:string;
	publishDate:string;
	bookImage:string;
	bookPrice:number;
	bookDescription:string;
}
