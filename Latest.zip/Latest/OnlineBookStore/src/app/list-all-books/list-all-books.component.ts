import { Component, OnInit } from '@angular/core';
import { Book } from '../book';
import { Router } from '@angular/router';
import { BookService } from '../book.service';

@Component({
  selector: 'app-list-all-books',
  templateUrl: './list-all-books.component.html',
  styleUrls: ['./list-all-books.component.css']
})
export class ListAllBooksComponent implements OnInit {

  books: Book[] = [];

  constructor(private router: Router, private bookService: BookService) {
  }

  ngOnInit() {
    this.bookService.getBooks().subscribe(data => {
      console.log(data);
      this.books = data;
    },
      err => { console.log(err) }
    );
  }

  deleteBook(book: Book) {
    this.bookService.deleteBook(book).subscribe(data => {
      this.books = this.books.filter(u => u !== book);
    })
  }

}
