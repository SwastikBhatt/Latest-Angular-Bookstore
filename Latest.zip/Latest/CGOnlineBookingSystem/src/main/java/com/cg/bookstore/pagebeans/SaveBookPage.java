package com.cg.bookstore.pagebeans;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class SaveBookPage {
	@FindBy(how=How.NAME,name="bookName")
	private WebElement bookName;
	
	@FindBy(how=How.NAME,name="authorName")
	private WebElement authorName;
	
	@FindBy(how=How.NAME,name="ISBN")
	private WebElement ISBN;
	
	@FindBy(how=How.NAME,name="publishDate")
	private WebElement publishDate;
	
	@FindBy(how=How.NAME,name="bookImage")
	private WebElement bookImage;
	
	@FindBy(how=How.NAME,name="bookPrice")
	private WebElement bookPrice;
	
	@FindBy(how=How.NAME,name="bookDescription")
	private WebElement bookDescription;
	
	@FindBy(how=How.NAME,name="bookCategory")
	private WebElement bookCategory;
	
	@FindBy(how=How.NAME,name="submit")
	private WebElement submitBtn;
	
	public String getBookName() {
		return bookName.getAttribute("value");
	}

	public void setBookName(String bookName) {
		this.bookName.sendKeys(bookName);;
	}
	
	public String getAuthorName() {
		return authorName.getAttribute("value");
	}

	public void setAuthorName(String authorName) {
		this.authorName.sendKeys(authorName);;
	}

	public String getISBN() {
		return ISBN.getAttribute("value");
	}

	public void setISBN(String ISBN) {
		this.ISBN.sendKeys(ISBN);
	}

	public String getPublishDate() {
		return publishDate.getAttribute("value");
	}

	public void setPublishDate(String publishDate) {
		this.publishDate.sendKeys(publishDate);;
	}

	public String getBookImage() {
		return bookImage.getAttribute("value");
	}

	public void setBookImage(String bookImage) {
		this.bookImage.sendKeys(bookImage);;
	}

	public String getBookPrice() {
		return bookPrice.getAttribute("value");
	}

	public void setBookPrice(String bookPrice) {
		this.bookPrice.sendKeys(bookPrice);;
	}

	public String getBookDescription() {
		return bookDescription.getAttribute("value");
	}

	public void setBookDescription(String bookDescription) {
		this.bookDescription.sendKeys(bookDescription);;
	}

	public String getBookCategory() {
		return bookCategory.getAttribute("value");
	}

	public void setBookCategory(String bookCategory) {
		this.bookCategory.sendKeys(bookCategory);;
	}

	public void clickSignUp() {
		submitBtn.click();
	}
}
